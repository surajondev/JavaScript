<html>
<body>
welcome <?php echo $_POST["usrname"]; ?><br>
Your password is: <?php echo $_POST["psw"]; ?>
</body>
</html>